# Chat Application using PHP with MySQL & Ajax

version: 1.0.0

## TECHNOLOGIES

1. PHP
1. MYSQL
1. JQUERY
1. BOOTSTRAP 5
1. HTML
1. CSS

## Full Tutorial

[On Youtube](https://youtu.be/JLnsWkQ-iB8)

## Authors

[Elias Abdurrahman](https://github.com/codingWithElias)
